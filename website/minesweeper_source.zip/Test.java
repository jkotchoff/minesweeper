import java.applet.Applet;
import java.awt.*;
import java.awt.event.*;

import java.io.*;

import java.util.Calendar;


public class Test extends Applet {



   public static void main(String[] args) throws IOException {

      String test = "jason " + 4 + " kotchoff";
      System.out.println(test);
   }
}
